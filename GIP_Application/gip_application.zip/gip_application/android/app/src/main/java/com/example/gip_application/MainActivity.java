package com.example.gip_application;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
